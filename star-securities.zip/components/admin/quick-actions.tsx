import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Building, Shield, FileText, Calendar } from "lucide-react"
import Link from "next/link"

const quickActions = [
  {
    title: "Thêm nhân viên",
    description: "Tạo hồ sơ nhân viên mới",
    icon: Users,
    href: "/admin/hr/employees/new",
    color: "bg-blue-100 text-blue-600",
  },
  {
    title: "Thêm khách hàng",
    description: "Tạo thông tin khách hàng mới",
    icon: Building,
    href: "/admin/customers/new",
    color: "bg-green-100 text-green-600",
  },
  {
    title: "Tạo dịch vụ",
    description: "Thiết lập dịch vụ bảo vệ mới",
    icon: Shield,
    href: "/admin/services/new",
    color: "bg-purple-100 text-purple-600",
  },
  {
    title: "Đăng tin tuyển dụng",
    description: "Tạo thông báo tuyển dụng",
    icon: FileText,
    href: "/admin/recruitment/jobs/new",
    color: "bg-orange-100 text-orange-600",
  },
  {
    title: "Lập lịch làm việc",
    description: "Sắp xếp ca làm việc",
    icon: Calendar,
    href: "/admin/hr/schedules",
    color: "bg-pink-100 text-pink-600",
  },
]

export function QuickActions() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Thao tác nhanh</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {quickActions.map((action, index) => (
            <Link key={index} href={action.href}>
              <Button variant="ghost" className="w-full justify-start h-auto p-4 hover:bg-muted/50">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${action.color}`}>
                    <action.icon className="h-5 w-5" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-foreground">{action.title}</p>
                    <p className="text-sm text-muted-foreground">{action.description}</p>
                  </div>
                </div>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
