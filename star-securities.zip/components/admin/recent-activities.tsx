import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const activities = [
  {
    id: 1,
    user: "Nguyễn Văn A",
    action: "Thêm nhân viên mới",
    target: "Trần Thị B - Bảo vệ",
    time: "5 phút trước",
    type: "create",
  },
  {
    id: 2,
    user: "Lê Văn C",
    action: "Cập nhật thông tin khách hàng",
    target: "Công ty TNHH XYZ",
    time: "15 phút trước",
    type: "update",
  },
  {
    id: 3,
    user: "Phạm Thị D",
    action: "Tạo hợp đồng mới",
    target: "Dịch vụ bảo vệ - ABC Corp",
    time: "30 phút trước",
    type: "create",
  },
  {
    id: 4,
    user: "Hoàng Văn E",
    action: "Phê duyệt đơn tuyển dụng",
    target: "Vị trí Trưởng ca bảo vệ",
    time: "1 giờ trước",
    type: "approve",
  },
  {
    id: 5,
    user: "Vũ Thị F",
    action: "Cập nhật lịch làm việc",
    target: "Ca đêm - Khu A",
    time: "2 giờ trước",
    type: "update",
  },
]

const getActivityColor = (type: string) => {
  switch (type) {
    case "create":
      return "bg-green-100 text-green-800"
    case "update":
      return "bg-blue-100 text-blue-800"
    case "approve":
      return "bg-purple-100 text-purple-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export function RecentActivities() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Hoạt động gần đây</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-4">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="text-xs">
                  {activity.user
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <p className="text-sm font-medium text-foreground">{activity.user}</p>
                  <Badge variant="secondary" className={getActivityColor(activity.type)}>
                    {activity.action}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{activity.target}</p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
