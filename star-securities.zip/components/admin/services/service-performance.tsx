"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"

const monthlyData = [
  { month: "T7", security: 28.5, transport: 12.3, electronic: 8.7, consulting: 3.2 },
  { month: "T8", security: 30.2, transport: 13.1, electronic: 9.2, consulting: 3.8 },
  { month: "T9", security: 29.8, transport: 12.8, electronic: 8.9, consulting: 3.5 },
  { month: "T10", security: 32.1, transport: 14.2, electronic: 9.8, consulting: 4.1 },
  { month: "T11", security: 31.5, transport: 13.9, electronic: 9.5, consulting: 3.9 },
  { month: "T12", security: 33.2, transport: 15.1, electronic: 10.2, consulting: 4.3 },
]

const serviceDistribution = [
  { name: "Dịch vụ bảo vệ", value: 33.2, color: "#8884d8" },
  { name: "Vận chuyển tiền", value: 15.1, color: "#82ca9d" },
  { name: "An ninh điện tử", value: 10.2, color: "#ffc658" },
  { name: "Tư vấn an ninh", value: 4.3, color: "#ff7300" },
]

export function ServicePerformance() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Doanh thu theo dịch vụ</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value}B VNĐ`, ""]} />
                <Bar dataKey="security" fill="#8884d8" name="Bảo vệ" />
                <Bar dataKey="transport" fill="#82ca9d" name="Vận chuyển" />
                <Bar dataKey="electronic" fill="#ffc658" name="An ninh điện tử" />
                <Bar dataKey="consulting" fill="#ff7300" name="Tư vấn" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border">
        <CardHeader>
          <CardTitle>Phân bố doanh thu tháng 12</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={serviceDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {serviceDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value}B VNĐ`, "Doanh thu"]} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
