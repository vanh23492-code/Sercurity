import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Truck, Camera, Users } from "lucide-react"

const activities = [
  {
    id: 1,
    service: "Dịch vụ bảo vệ",
    icon: Shield,
    action: "Ký hợp đồng mới",
    customer: "Công ty TNHH ABC",
    value: "2.5B VNĐ",
    time: "30 phút trước",
    type: "contract",
  },
  {
    id: 2,
    service: "An ninh điện tử",
    icon: Camera,
    action: "Lắp đặt hoàn thành",
    customer: "Tập đoàn XYZ",
    value: "1.8B VNĐ",
    time: "1 giờ trước",
    type: "installation",
  },
  {
    id: 3,
    service: "Vận chuyển tiền",
    icon: Truck,
    action: "Hoàn thành vận chuyển",
    customer: "Ngân hàng GHI",
    value: "50M VNĐ",
    time: "2 giờ trước",
    type: "completion",
  },
  {
    id: 4,
    service: "Tư vấn an ninh",
    icon: Users,
    action: "Báo cáo đánh giá",
    customer: "Khách sạn JKL",
    value: "300M VNĐ",
    time: "3 giờ trước",
    type: "report",
  },
  {
    id: 5,
    service: "Dịch vụ bảo vệ",
    icon: Shield,
    action: "Đánh giá chất lượng",
    customer: "Công ty Cổ phần DEF",
    value: "5 sao",
    time: "4 giờ trước",
    type: "review",
  },
]

const getActivityColor = (type: string) => {
  switch (type) {
    case "contract":
      return "bg-green-100 text-green-800"
    case "installation":
      return "bg-blue-100 text-blue-800"
    case "completion":
      return "bg-purple-100 text-purple-800"
    case "report":
      return "bg-yellow-100 text-yellow-800"
    case "review":
      return "bg-pink-100 text-pink-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export function RecentServiceActivities() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Hoạt động dịch vụ gần đây</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <activity.icon className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <p className="text-sm font-medium text-foreground">{activity.service}</p>
                  <Badge variant="secondary" className={getActivityColor(activity.type)}>
                    {activity.action}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{activity.customer}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs font-medium text-primary">{activity.value}</span>
                  <span className="text-xs text-muted-foreground">{activity.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
