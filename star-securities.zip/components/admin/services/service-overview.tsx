import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Plus, Shield, Truck, Camera, Users } from "lucide-react"
import Link from "next/link"

const services = [
  {
    id: 1,
    name: "Dịch vụ bảo vệ cơ bản",
    category: "Bảo vệ",
    icon: Shield,
    description: "Dịch vụ bảo vệ 24/7 cho doanh nghiệp và khu dân cư",
    price: "15,000,000 VNĐ/tháng",
    status: "active",
    clients: 234,
    features: ["Bảo vệ 24/7", "Tuần tra định kỳ", "Báo cáo hàng ngày"],
  },
  {
    id: 2,
    name: "Vận chuyển tiền mặt",
    category: "Vận chuyển",
    icon: Truck,
    description: "Vận chuyển tiền mặt và tài sản có giá trị cao",
    price: "2,500,000 VNĐ/chuyến",
    status: "active",
    clients: 89,
    features: ["Xe bọc thép", "GPS tracking", "Bảo hiểm toàn diện"],
  },
  {
    id: 3,
    name: "Hệ thống camera AI",
    category: "An ninh điện tử",
    icon: Camera,
    description: "Lắp đặt và vận hành hệ thống camera giám sát AI",
    price: "50,000,000 VNĐ/hệ thống",
    status: "active",
    clients: 156,
    features: ["Camera AI", "Phân tích hành vi", "Cảnh báo thời gian thực"],
  },
  {
    id: 4,
    name: "Tư vấn an ninh doanh nghiệp",
    category: "Tư vấn",
    icon: Users,
    description: "Đánh giá và tư vấn giải pháp an ninh tổng thể",
    price: "25,000,000 VNĐ/dự án",
    status: "active",
    clients: 67,
    features: ["Đánh giá rủi ro", "Thiết kế giải pháp", "Đào tạo nhân viên"],
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-100 text-green-800">Đang cung cấp</Badge>
    case "inactive":
      return <Badge className="bg-red-100 text-red-800">Ngừng cung cấp</Badge>
    case "development":
      return <Badge className="bg-yellow-100 text-yellow-800">Đang phát triển</Badge>
    default:
      return <Badge variant="secondary">Không xác định</Badge>
  }
}

export function ServiceOverview() {
  return (
    <Card className="border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Danh sách dịch vụ</CardTitle>
          <Link href="/admin/services/new">
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Thêm dịch vụ
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {services.map((service) => (
            <div key={service.id} className="border border-border rounded-lg p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <service.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{service.name}</h4>
                    <p className="text-sm text-muted-foreground">{service.category}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {getStatusBadge(service.status)}
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <p className="text-muted-foreground mb-4">{service.description}</p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <p className="text-sm text-muted-foreground">Giá dịch vụ</p>
                  <p className="font-semibold text-primary">{service.price}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Số khách hàng</p>
                  <p className="font-semibold text-foreground">{service.clients} khách hàng</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tính năng chính</p>
                  <p className="font-semibold text-foreground">{service.features.length} tính năng</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {service.features.map((feature, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
