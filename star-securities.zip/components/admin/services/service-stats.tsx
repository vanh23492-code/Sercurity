import { Card, CardContent } from "@/components/ui/card"
import { Shield, Truck, Camera, Users } from "lucide-react"

const stats = [
  {
    title: "Dịch vụ bảo vệ",
    value: "1,234",
    change: "Hợp đồng đang hoạt động",
    changeType: "neutral" as const,
    icon: Shield,
    revenue: "28.5B VNĐ",
  },
  {
    title: "Vận chuyển tiền mặt",
    value: "456",
    change: "Chuyến vận chuyển/tháng",
    changeType: "neutral" as const,
    icon: Truck,
    revenue: "12.3B VNĐ",
  },
  {
    title: "An ninh điện tử",
    value: "789",
    change: "Hệ thống đang vận hành",
    changeType: "neutral" as const,
    icon: Camera,
    revenue: "8.7B VNĐ",
  },
  {
    title: "Tư vấn an ninh",
    value: "123",
    change: "Dự án tư vấn",
    changeType: "neutral" as const,
    icon: Users,
    revenue: "3.2B VNĐ",
  },
]

export function ServiceStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Doanh thu</p>
                <p className="text-sm font-semibold text-primary">{stat.revenue}</p>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.change}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
