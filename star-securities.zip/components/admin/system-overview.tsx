"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { month: "T1", employees: 1100, customers: 780, services: 2100 },
  { month: "T2", employees: 1150, customers: 820, services: 2200 },
  { month: "T3", employees: 1180, customers: 840, services: 2250 },
  { month: "T4", employees: 1200, customers: 850, services: 2300 },
  { month: "T5", employees: 1220, customers: 855, services: 2320 },
  { month: "T6", employees: 1247, customers: 856, services: 2341 },
]

export function SystemOverview() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Tổng quan hệ thống</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="employees" fill="#8884d8" name="Nhân viên" />
              <Bar dataKey="customers" fill="#82ca9d" name="Khách hàng" />
              <Bar dataKey="services" fill="#ffc658" name="Dịch vụ" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
