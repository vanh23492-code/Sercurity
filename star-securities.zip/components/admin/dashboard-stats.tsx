import { Card, CardContent } from "@/components/ui/card"
import { Users, Shield, Building, TrendingUp } from "lucide-react"

const stats = [
  {
    title: "Tổng nhân viên",
    value: "1,247",
    change: "+12%",
    changeType: "positive" as const,
    icon: Users,
  },
  {
    title: "Khách hàng hoạt động",
    value: "856",
    change: "+8%",
    changeType: "positive" as const,
    icon: Building,
  },
  {
    title: "Dịch vụ đang cung cấp",
    value: "2,341",
    change: "+15%",
    changeType: "positive" as const,
    icon: Shield,
  },
  {
    title: "Doanh thu tháng",
    value: "45.2B VNĐ",
    change: "+23%",
    changeType: "positive" as const,
    icon: TrendingUp,
  },
]

export function DashboardStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className={`text-sm ${stat.changeType === "positive" ? "text-green-600" : "text-red-600"}`}>
                  {stat.change} so với tháng trước
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
