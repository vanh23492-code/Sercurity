import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MoreHorizontal, Plus } from "lucide-react"
import Link from "next/link"

const employees = [
  {
    id: 1,
    name: "Nguyễn Văn An",
    position: "Trưởng ca bảo vệ",
    department: "Bảo vệ",
    status: "active",
    location: "Hà Nội",
    joinDate: "2020-03-15",
  },
  {
    id: 2,
    name: "Trần Thị Bình",
    position: "Nhân viên bảo vệ",
    department: "Bảo vệ",
    status: "active",
    location: "TP.HCM",
    joinDate: "2021-07-20",
  },
  {
    id: 3,
    name: "Lê Văn Cường",
    position: "Kỹ thuật viên",
    department: "An ninh điện tử",
    status: "leave",
    location: "Đà Nẵng",
    joinDate: "2019-11-10",
  },
  {
    id: 4,
    name: "Phạm Thị Dung",
    position: "Chuyên viên HR",
    department: "Nhân sự",
    status: "active",
    location: "Hà Nội",
    joinDate: "2022-01-05",
  },
  {
    id: 5,
    name: "Hoàng Văn Em",
    position: "Tài xế vận chuyển",
    department: "Vận chuyển",
    status: "active",
    location: "TP.HCM",
    joinDate: "2020-09-12",
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-100 text-green-800">Đang làm việc</Badge>
    case "leave":
      return <Badge className="bg-yellow-100 text-yellow-800">Nghỉ phép</Badge>
    case "inactive":
      return <Badge className="bg-red-100 text-red-800">Không hoạt động</Badge>
    default:
      return <Badge variant="secondary">Không xác định</Badge>
  }
}

export function EmployeeOverview() {
  return (
    <Card className="border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Danh sách nhân viên</CardTitle>
          <Link href="/admin/hr/employees/new">
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Thêm nhân viên
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {employees.map((employee) => (
            <div key={employee.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarFallback>
                    {employee.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium text-foreground">{employee.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {employee.position} • {employee.department}
                  </p>
                  <p className="text-xs text-muted-foreground">{employee.location}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                {getStatusBadge(employee.status)}
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link href="/admin/hr/employees">
            <Button variant="outline">Xem tất cả nhân viên</Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
