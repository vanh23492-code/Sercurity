import { Card, CardContent } from "@/components/ui/card"
import { Users, UserCheck, UserX, Clock } from "lucide-react"

const stats = [
  {
    title: "Tổng nhân viên",
    value: "1,247",
    change: "+12 nhân viên mới",
    changeType: "positive" as const,
    icon: Users,
  },
  {
    title: "Đang làm việc",
    value: "1,198",
    change: "96% tổng số",
    changeType: "positive" as const,
    icon: UserCheck,
  },
  {
    title: "Nghỉ phép hôm nay",
    value: "23",
    change: "1.8% tổng số",
    changeType: "neutral" as const,
    icon: UserX,
  },
  {
    title: "Giờ làm trung bình",
    value: "8.2h",
    change: "+0.3h so với tháng trước",
    changeType: "positive" as const,
    icon: Clock,
  },
]

export function HRStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p
                  className={`text-sm ${
                    stat.changeType === "positive"
                      ? "text-green-600"
                      : stat.changeType === "negative"
                        ? "text-red-600"
                        : "text-muted-foreground"
                  }`}
                >
                  {stat.change}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
