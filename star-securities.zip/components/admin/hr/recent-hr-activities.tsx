import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const activities = [
  {
    id: 1,
    employee: "Nguyễn Văn A",
    action: "Đăng ký nghỉ phép",
    details: "3 ngày từ 15/01 - 17/01",
    time: "10 phút trước",
    type: "leave",
  },
  {
    id: 2,
    employee: "Trần Thị B",
    action: "Cập nhật thông tin",
    details: "Thay đổi địa chỉ liên hệ",
    time: "25 phút trước",
    type: "update",
  },
  {
    id: 3,
    employee: "Lê Văn C",
    action: "Hoàn thành đào tạo",
    details: "Khóa An toàn lao động",
    time: "1 giờ trước",
    type: "training",
  },
  {
    id: 4,
    employee: "Phạm Thị D",
    action: "Đánh giá hiệu suất",
    details: "Quý 4/2024 - Xuất sắc",
    time: "2 giờ trước",
    type: "evaluation",
  },
  {
    id: 5,
    employee: "Hoàng Văn E",
    action: "Chấm công muộn",
    details: "Muộn 15 phút",
    time: "3 giờ trước",
    type: "attendance",
  },
]

const getActivityColor = (type: string) => {
  switch (type) {
    case "leave":
      return "bg-yellow-100 text-yellow-800"
    case "update":
      return "bg-blue-100 text-blue-800"
    case "training":
      return "bg-green-100 text-green-800"
    case "evaluation":
      return "bg-purple-100 text-purple-800"
    case "attendance":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export function RecentHRActivities() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Hoạt động HR gần đây</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="text-xs">
                  {activity.employee
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <p className="text-sm font-medium text-foreground">{activity.employee}</p>
                  <Badge variant="secondary" className={getActivityColor(activity.type)}>
                    {activity.action}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{activity.details}</p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
