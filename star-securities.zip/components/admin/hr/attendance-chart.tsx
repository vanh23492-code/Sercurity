"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { day: "T2", present: 1180, absent: 67 },
  { day: "T3", present: 1195, absent: 52 },
  { day: "T4", present: 1203, absent: 44 },
  { day: "T5", present: 1189, absent: 58 },
  { day: "T6", present: 1198, absent: 49 },
  { day: "T7", present: 1156, absent: 91 },
  { day: "CN", present: 1134, absent: 113 },
]

export function AttendanceChart() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Chấm công tuần này</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="present" stroke="#8884d8" strokeWidth={2} name="Có mặt" />
              <Line type="monotone" dataKey="absent" stroke="#82ca9d" strokeWidth={2} name="Vắng mặt" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
