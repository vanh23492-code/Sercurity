import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MoreHorizontal, Plus, Building } from "lucide-react"
import Link from "next/link"

const customers = [
  {
    id: 1,
    name: "Công ty TNHH ABC",
    contact: "Nguyễn Văn A",
    email: "contact@abc.com.vn",
    phone: "024 3333 1111",
    industry: "Sản xuất",
    status: "active",
    contractValue: "2.5B VNĐ",
    startDate: "2023-01-15",
    services: ["Bảo vệ", "An ninh điện tử"],
  },
  {
    id: 2,
    name: "Tập đoàn XYZ",
    contact: "Trần Thị B",
    email: "info@xyz.vn",
    phone: "028 3888 2222",
    industry: "Bất động sản",
    status: "active",
    contractValue: "5.8B VNĐ",
    startDate: "2022-08-20",
    services: ["Bảo vệ", "Vận chuyển tiền"],
  },
  {
    id: 3,
    name: "Công ty Cổ phần DEF",
    contact: "Lê Văn C",
    email: "admin@def.com",
    phone: "0236 3777 3333",
    industry: "Công nghệ",
    status: "pending",
    contractValue: "1.2B VNĐ",
    startDate: "2024-01-10",
    services: ["An ninh điện tử"],
  },
  {
    id: 4,
    name: "Ngân hàng GHI",
    contact: "Phạm Thị D",
    email: "security@ghi.bank",
    phone: "024 3999 4444",
    industry: "Tài chính",
    status: "active",
    contractValue: "12.5B VNĐ",
    startDate: "2021-03-05",
    services: ["Bảo vệ", "Vận chuyển tiền", "An ninh điện tử"],
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-100 text-green-800">Đang hoạt động</Badge>
    case "pending":
      return <Badge className="bg-yellow-100 text-yellow-800">Chờ xử lý</Badge>
    case "expired":
      return <Badge className="bg-red-100 text-red-800">Hết hạn</Badge>
    default:
      return <Badge variant="secondary">Không xác định</Badge>
  }
}

export function CustomerOverview() {
  return (
    <Card className="border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Danh sách khách hàng</CardTitle>
          <Link href="/admin/customers/new">
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Thêm khách hàng
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {customers.map((customer) => (
            <div key={customer.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <Avatar className="h-12 w-12">
                  <AvatarFallback>
                    <Building className="h-6 w-6" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium text-foreground">{customer.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {customer.contact} • {customer.industry}
                  </p>
                  <p className="text-sm text-muted-foreground">{customer.email}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-xs font-medium text-primary">{customer.contractValue}</span>
                    <span className="text-xs text-muted-foreground">•</span>
                    <span className="text-xs text-muted-foreground">{customer.services.length} dịch vụ</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                {getStatusBadge(customer.status)}
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link href="/admin/customers/list">
            <Button variant="outline">Xem tất cả khách hàng</Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
