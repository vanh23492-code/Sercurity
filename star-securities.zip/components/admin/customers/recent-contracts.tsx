import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Calendar, DollarSign } from "lucide-react"

const contracts = [
  {
    id: 1,
    customer: "Công ty TNHH ABC",
    service: "Dịch vụ bảo vệ",
    value: "2.5B VNĐ",
    startDate: "2024-01-15",
    endDate: "2024-12-31",
    status: "active",
    type: "Gia hạn",
  },
  {
    id: 2,
    customer: "Tập đoàn XYZ",
    service: "Vận chuyển tiền mặt",
    value: "3.2B VNĐ",
    startDate: "2024-01-20",
    endDate: "2025-01-19",
    status: "active",
    type: "Mới",
  },
  {
    id: 3,
    customer: "Ngân hàng GHI",
    service: "An ninh điện tử",
    value: "4.8B VNĐ",
    startDate: "2024-02-01",
    endDate: "2026-01-31",
    status: "pending",
    type: "Nâng cấp",
  },
  {
    id: 4,
    customer: "Công ty Cổ phần DEF",
    service: "Tư vấn an ninh",
    value: "800M VNĐ",
    startDate: "2024-01-25",
    endDate: "2024-06-30",
    status: "active",
    type: "Mới",
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-100 text-green-800">Đang hoạt động</Badge>
    case "pending":
      return <Badge className="bg-yellow-100 text-yellow-800">Chờ phê duyệt</Badge>
    case "expired":
      return <Badge className="bg-red-100 text-red-800">Hết hạn</Badge>
    default:
      return <Badge variant="secondary">Không xác định</Badge>
  }
}

const getTypeBadge = (type: string) => {
  switch (type) {
    case "Mới":
      return (
        <Badge variant="outline" className="text-blue-600 border-blue-200">
          Mới
        </Badge>
      )
    case "Gia hạn":
      return (
        <Badge variant="outline" className="text-green-600 border-green-200">
          Gia hạn
        </Badge>
      )
    case "Nâng cấp":
      return (
        <Badge variant="outline" className="text-purple-600 border-purple-200">
          Nâng cấp
        </Badge>
      )
    default:
      return <Badge variant="outline">Khác</Badge>
  }
}

export function RecentContracts() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Hợp đồng gần đây</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {contracts.map((contract) => (
            <div key={contract.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">{contract.customer}</h4>
                  <p className="text-sm text-muted-foreground">{contract.service}</p>
                  <div className="flex items-center space-x-4 mt-1">
                    <div className="flex items-center space-x-1">
                      <DollarSign className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs font-medium text-primary">{contract.value}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">
                        {contract.startDate} - {contract.endDate}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {getTypeBadge(contract.type)}
                {getStatusBadge(contract.status)}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
