import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Building } from "lucide-react"

const activities = [
  {
    id: 1,
    customer: "Công ty TNHH ABC",
    action: "Ký hợp đồng mới",
    details: "Dịch vụ bảo vệ - 2.5B VNĐ",
    time: "15 phút trước",
    type: "contract",
  },
  {
    id: 2,
    customer: "Tập đoàn XYZ",
    action: "Cập nhật thông tin",
    details: "Thay đổi người liên hệ",
    time: "1 giờ trước",
    type: "update",
  },
  {
    id: 3,
    customer: "Ngân hàng GHI",
    action: "Thanh toán hóa đơn",
    details: "Tháng 12/2024 - 1.2B VNĐ",
    time: "2 giờ trước",
    type: "payment",
  },
  {
    id: 4,
    customer: "Công ty Cổ phần DEF",
    action: "Yêu cầu báo giá",
    details: "Dịch vụ an ninh điện tử",
    time: "3 giờ trước",
    type: "inquiry",
  },
  {
    id: 5,
    customer: "Khách sạn JKL",
    action: "Đánh giá dịch vụ",
    details: "5 sao - Rất hài lòng",
    time: "4 giờ trước",
    type: "review",
  },
]

const getActivityColor = (type: string) => {
  switch (type) {
    case "contract":
      return "bg-green-100 text-green-800"
    case "update":
      return "bg-blue-100 text-blue-800"
    case "payment":
      return "bg-purple-100 text-purple-800"
    case "inquiry":
      return "bg-yellow-100 text-yellow-800"
    case "review":
      return "bg-pink-100 text-pink-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export function CustomerActivities() {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle>Hoạt động khách hàng</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3">
              <Avatar className="h-8 w-8">
                <AvatarFallback>
                  <Building className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <p className="text-sm font-medium text-foreground">{activity.customer}</p>
                  <Badge variant="secondary" className={getActivityColor(activity.type)}>
                    {activity.action}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{activity.details}</p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
