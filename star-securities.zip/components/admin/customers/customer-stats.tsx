import { Card, CardContent } from "@/components/ui/card"
import { Building, FileText, TrendingUp, Clock } from "lucide-react"

const stats = [
  {
    title: "Tổng khách hàng",
    value: "856",
    change: "+24 khách hàng mới",
    changeType: "positive" as const,
    icon: Building,
  },
  {
    title: "Hợp đồng đang hoạt động",
    value: "1,234",
    change: "89% tổng số",
    changeType: "positive" as const,
    icon: FileText,
  },
  {
    title: "Doanh thu tháng này",
    value: "45.2B VNĐ",
    change: "+18% so với tháng trước",
    changeType: "positive" as const,
    icon: TrendingUp,
  },
  {
    title: "Hợp đồng sắp hết hạn",
    value: "23",
    change: "Trong 30 ngày tới",
    changeType: "warning" as const,
    icon: Clock,
  },
]

export function CustomerStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p
                  className={`text-sm ${
                    stat.changeType === "positive"
                      ? "text-green-600"
                      : stat.changeType === "negative"
                        ? "text-red-600"
                        : stat.changeType === "warning"
                          ? "text-yellow-600"
                          : "text-muted-foreground"
                  }`}
                >
                  {stat.change}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
