import { Button } from "@/components/ui/button"
import { ArrowRight, Phone } from "lucide-react"
import Link from "next/link"

export function CTASection() {
  return (
    <section className="py-20 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="bg-primary rounded-3xl p-8 md:p-16 text-center text-primary-foreground">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Sẵn sàng bảo vệ doanh nghiệp của bạn?</h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-3xl mx-auto text-pretty">
            Liên hệ với chúng tôi ngay hôm nay để được tư vấn miễn phí về giải pháp bảo vệ phù hợp nhất cho doanh nghiệp
            của bạn.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
                Liên hệ ngay
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="tel:+842433334444">
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary text-lg px-8 py-4 bg-transparent"
              >
                <Phone className="mr-2 h-5 w-5" />
                Hotline: 024 3333 4444
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
