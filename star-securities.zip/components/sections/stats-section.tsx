const stats = [
  {
    number: "1,000+",
    label: "Khách hàng tin tưởng",
    description: "Doanh nghiệp và tổ chức",
  },
  {
    number: "5,000+",
    label: "Nhân viên chuyên nghiệp",
    description: "Được đào tạo bài bản",
  },
  {
    number: "24/7",
    label: "Hỗ trợ liên tục",
    description: "Mọi lúc, mọi nơi",
  },
  {
    number: "99.9%",
    label: "Độ tin cậy",
    description: "Cam kết chất lượng",
  },
]

export function StatsSection() {
  return (
    <section className="py-20 bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Con số ấn tượng về Star Securities</h2>
          <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto text-pretty">
            Những thành tựu đạt được trong suốt hành trình phát triển của chúng tôi
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl md:text-5xl font-bold mb-2">{stat.number}</div>
              <div className="text-lg font-semibold mb-1">{stat.label}</div>
              <div className="text-primary-foreground/70 text-sm">{stat.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
