import { Card, CardContent } from "@/components/ui/card"
import { Shield, Truck, Camera, Users, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const services = [
  {
    icon: Shield,
    title: "Dịch vụ bảo vệ",
    description:
      "Cung cấp nhân viên bảo vệ chuyên nghiệp cho các doanh nghiệp, khu công nghiệp, và khu dân cư với đào tạo bài bản.",
    features: ["Bảo vệ 24/7", "Đào tạo chuyên nghiệp", "Trang thiết bị hiện đại"],
  },
  {
    icon: Truck,
    title: "Vận chuyển tiền mặt",
    description:
      "Dịch vụ vận chuyển tiền mặt và tài sản có giá trị cao với hệ thống bảo mật tối ưu và đội ngũ được đào tạo đặc biệt.",
    features: ["Xe bọc thép", "GPS tracking", "Bảo hiểm toàn diện"],
  },
  {
    icon: Camera,
    title: "An ninh điện tử",
    description: "Lắp đặt và vận hành hệ thống camera giám sát, báo động, kiểm soát ra vào với công nghệ AI tiên tiến.",
    features: ["Camera AI", "Báo động thông minh", "Giám sát từ xa"],
  },
  {
    icon: Users,
    title: "Tư vấn an ninh",
    description: "Đánh giá rủi ro và tư vấn giải pháp an ninh tổng thể phù hợp với từng loại hình doanh nghiệp.",
    features: ["Đánh giá rủi ro", "Thiết kế giải pháp", "Hỗ trợ 24/7"],
  },
]

export function ServicesSection() {
  return (
    <section className="py-20 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-4">Dịch vụ chính</h2>
          <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
            Giải pháp bảo vệ toàn diện
            <br />
            cho mọi nhu cầu
          </h3>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            Chúng tôi cung cấp các dịch vụ bảo vệ đa dạng với công nghệ hiện đại và đội ngũ chuyên nghiệp, đáp ứng mọi
            yêu cầu về an ninh của khách hàng.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-border">
              <CardContent className="p-8">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <service.icon className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-xl font-semibold text-foreground mb-3">{service.title}</h4>
                    <p className="text-muted-foreground mb-4 text-pretty">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mr-3" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link href="/services">
            <Button size="lg" className="text-lg px-8 py-4">
              Xem tất cả dịch vụ
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
