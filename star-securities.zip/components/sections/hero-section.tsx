import { Button } from "@/components/ui/button"
import { Shield, ArrowRight } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/professional-security-team-in-dark-suits-monitorin.jpg"
          alt="Star Securities Professional Team"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 hero-gradient" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="fade-in">
          <div className="flex items-center justify-center mb-6">
            <Shield className="h-16 w-16 text-white" />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
            Star Securities là đối tác tin cậy
            <br />
            trong lĩnh vực dịch vụ bảo vệ chuyên nghiệp
          </h1>

          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto text-pretty">
            Chúng tôi cung cấp giải pháp bảo vệ toàn diện cho con người, tài sản và hệ thống an ninh điện tử với đội ngũ
            chuyên nghiệp và công nghệ hiện đại.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/services">
              <Button size="lg" className="bg-white text-black hover:bg-white/90 text-lg px-8 py-4">
                Khám phá dịch vụ
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-black text-lg px-8 py-4 bg-transparent"
              >
                Liên hệ tư vấn
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse" />
        </div>
      </div>
    </section>
  )
}
