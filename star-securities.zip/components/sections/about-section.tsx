import { Button } from "@/components/ui/button"
import { CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"

const achievements = [
  "Hơn 15 năm kinh nghiệm trong ngành bảo vệ",
  "Đội ngũ hơn 5,000 nhân viên chuyên nghiệp",
  "Phục vụ hơn 1,000 khách hàng trên toàn quốc",
  "Chứng nhận ISO 9001:2015 về chất lượng dịch vụ",
]

export function AboutSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="slide-up">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-4">
              Về Star Securities
            </h2>
            <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
              Đối tác tin cậy trong lĩnh vực bảo vệ chuyên nghiệp
            </h3>
            <p className="text-lg text-muted-foreground mb-8 text-pretty">
              Star Securities được thành lập với sứ mệnh cung cấp các giải pháp bảo vệ toàn diện và chuyên nghiệp. Chúng
              tôi cam kết mang đến sự an toàn tuyệt đối cho khách hàng thông qua đội ngũ được đào tạo bài bản và công
              nghệ hiện đại nhất.
            </p>

            <div className="space-y-4 mb-8">
              {achievements.map((achievement, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">{achievement}</span>
                </div>
              ))}
            </div>

            <Link href="/about">
              <Button size="lg" className="text-lg px-8 py-4">
                Tìm hiểu thêm
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden">
              <img src="/professional-security-team-meeting-in-modern-offic.jpg" alt="Star Securities Team" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-primary rounded-2xl flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-foreground">15+</div>
                <div className="text-xs text-primary-foreground/80">Năm kinh nghiệm</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
