"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  Shield,
  LayoutDashboard,
  Users,
  Building,
  Briefcase,
  UserPlus,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

const navigation = [
  {
    name: "Bảng điều khiển",
    href: "/admin",
    icon: LayoutDashboard,
  },
  {
    name: "Quản lý nhân sự",
    href: "/admin/hr",
    icon: Users,
  },
  {
    name: "Quản lý khách hàng",
    href: "/admin/customers",
    icon: Building,
  },
  {
    name: "Quản lý dịch vụ",
    href: "/admin/services",
    icon: Briefcase,
  },
  {
    name: "Tuyển dụng",
    href: "/admin/recruitment",
    icon: UserPlus,
  },
  {
    name: "Cài đặt",
    href: "/admin/settings",
    icon: Settings,
  },
]

interface AdminSidebarProps {
  className?: string
}

export function AdminSidebar({ className }: AdminSidebarProps) {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()

  return (
    <div className={cn("flex flex-col bg-primary text-primary-foreground", className)}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-primary-foreground/20">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8" />
            <span className="text-lg font-bold">Star Securities</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCollapsed(!collapsed)}
          className="text-primary-foreground hover:bg-primary-foreground/20"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => (
            <li key={item.name}>
              <Link
                href={item.href}
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-lg text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/20 transition-colors",
                  pathname === item.href && "bg-primary-foreground/20 text-primary-foreground",
                )}
              >
                <item.icon className="h-5 w-5 flex-shrink-0" />
                {!collapsed && <span>{item.name}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-primary-foreground/20">
        <Button variant="ghost" className="w-full justify-start text-primary-foreground hover:bg-primary-foreground/20">
          <LogOut className="h-5 w-5 mr-3" />
          {!collapsed && "Đăng xuất"}
        </Button>
      </div>
    </div>
  )
}
