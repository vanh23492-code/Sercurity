import Link from "next/link"
import { Shield, Phone, Mail, MapPin, Facebook, Linkedin, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <Shield className="h-8 w-8" />
                <span className="text-xl font-bold">Star Securities</span>
              </div>
              <p className="text-primary-foreground/80 mb-4 max-w-md">
                Công ty dịch vụ bảo vệ hàng đầu Việt Nam, cung cấp giải pháp bảo vệ toàn diện cho con người, tài sản và
                hệ thống an ninh điện tử.
              </p>
              <div className="flex space-x-4">
                <Link href="#" className="text-primary-foreground/80 hover:text-primary-foreground">
                  <Facebook className="h-5 w-5" />
                </Link>
                <Link href="#" className="text-primary-foreground/80 hover:text-primary-foreground">
                  <Linkedin className="h-5 w-5" />
                </Link>
                <Link href="#" className="text-primary-foreground/80 hover:text-primary-foreground">
                  <Twitter className="h-5 w-5" />
                </Link>
              </div>
            </div>

            {/* Services */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Dịch vụ</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/services/security" className="text-primary-foreground/80 hover:text-primary-foreground">
                    Dịch vụ bảo vệ
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/cash-transport"
                    className="text-primary-foreground/80 hover:text-primary-foreground"
                  >
                    Vận chuyển tiền mặt
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/electronic-security"
                    className="text-primary-foreground/80 hover:text-primary-foreground"
                  >
                    An ninh điện tử
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/consulting"
                    className="text-primary-foreground/80 hover:text-primary-foreground"
                  >
                    Tư vấn an ninh
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Liên hệ</h3>
              <ul className="space-y-3">
                <li className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span className="text-primary-foreground/80">+84 24 3xxx xxxx</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span className="text-primary-foreground/80">info@starsecurities.vn</span>
                </li>
                <li className="flex items-start space-x-2">
                  <MapPin className="h-4 w-4 mt-1" />
                  <span className="text-primary-foreground/80">
                    123 Đường ABC, Quận XYZ
                    <br />
                    Thành phố Hà Nội, Việt Nam
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-primary-foreground/80 text-sm">© 2025 Star Securities. Tất cả quyền được bảo lưu.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/privacy" className="text-primary-foreground/80 hover:text-primary-foreground text-sm">
                Chính sách bảo mật
              </Link>
              <Link href="/terms" className="text-primary-foreground/80 hover:text-primary-foreground text-sm">
                Điều khoản sử dụng
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
