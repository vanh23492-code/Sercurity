import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Shield, Truck, Camera, Users, CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"

const services = [
  {
    id: 1,
    name: "Dịch vụ bảo vệ",
    icon: Shield,
    description: "Cung cấp nhân viên bảo vệ chuyên nghiệp 24/7 cho doanh nghiệp, khu công nghiệp và khu dân cư.",
    price: "Từ 15,000,000 VNĐ/tháng",
    features: [
      "Bảo vệ 24/7 tại chỗ",
      "Tuần tra định kỳ",
      "Kiểm soát ra vào",
      "Báo cáo hàng ngày",
      "Đào tạo chuyên nghiệp",
      "Trang thiết bị hiện đại",
    ],
    popular: true,
  },
  {
    id: 2,
    name: "Vận chuyển tiền mặt",
    icon: Truck,
    description: "Dịch vụ vận chuyển tiền mặt và tài sản có giá trị cao với hệ thống bảo mật tối ưu.",
    price: "Từ 2,500,000 VNĐ/chuyến",
    features: [
      "Xe bọc thép chuyên dụng",
      "GPS tracking thời gian thực",
      "Bảo hiểm toàn diện",
      "Đội ngũ được đào tạo đặc biệt",
      "Hệ thống báo động",
      "Hỗ trợ 24/7",
    ],
    popular: false,
  },
  {
    id: 3,
    name: "An ninh điện tử",
    icon: Camera,
    description: "Lắp đặt và vận hành hệ thống camera giám sát, báo động với công nghệ AI tiên tiến.",
    price: "Từ 50,000,000 VNĐ/hệ thống",
    features: [
      "Camera AI thông minh",
      "Phân tích hành vi",
      "Cảnh báo thời gian thực",
      "Lưu trữ đám mây",
      "Giám sát từ xa",
      "Báo động tự động",
    ],
    popular: false,
  },
  {
    id: 4,
    name: "Tư vấn an ninh",
    icon: Users,
    description: "Đánh giá rủi ro và tư vấn giải pháp an ninh tổng thể phù hợp với từng doanh nghiệp.",
    price: "Từ 25,000,000 VNĐ/dự án",
    features: [
      "Đánh giá rủi ro toàn diện",
      "Thiết kế giải pháp tùy chỉnh",
      "Đào tạo nhân viên",
      "Hỗ trợ triển khai",
      "Theo dõi và đánh giá",
      "Tư vấn 24/7",
    ],
    popular: false,
  },
]

export default function ServicesPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Dịch vụ bảo vệ chuyên nghiệp
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Chúng tôi cung cấp đầy đủ các dịch vụ bảo vệ từ cơ bản đến nâng cao, đáp ứng mọi nhu cầu an ninh của khách
              hàng với công nghệ hiện đại và đội ngũ chuyên nghiệp.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.map((service) => (
              <Card key={service.id} className="border-border relative overflow-hidden">
                {service.popular && (
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-primary text-primary-foreground">Phổ biến nhất</Badge>
                  </div>
                )}
                <CardContent className="p-8">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center">
                      <service.icon className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-foreground">{service.name}</h3>
                      <p className="text-lg font-semibold text-primary">{service.price}</p>
                    </div>
                  </div>

                  <p className="text-muted-foreground mb-6 text-pretty">{service.description}</p>

                  <div className="space-y-3 mb-8">
                    {service.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                        <span className="text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Link href="/contact">
                    <Button className="w-full text-lg py-6">
                      Liên hệ tư vấn
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Cần tư vấn giải pháp an ninh phù hợp?</h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-3xl mx-auto text-pretty">
            Đội ngũ chuyên gia của chúng tôi sẵn sàng tư vấn miễn phí để tìm ra giải pháp bảo vệ tối ưu nhất cho doanh
            nghiệp của bạn.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
                Tư vấn miễn phí
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="tel:+842433334444">
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary text-lg px-8 py-4 bg-transparent"
              >
                Hotline: 024 3333 4444
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
