import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"

const inter = Inter({
  subsets: ["latin", "vietnamese"],
  variable: "--font-sans",
})

export const metadata: Metadata = {
  title: "Star Securities - Dịch vụ bảo vệ chuyên nghiệp",
  description:
    "Công ty dịch vụ bảo vệ hàng đầu Việt Nam, cung cấp giải pháp bảo vệ toàn diện cho con người, tài sản và hệ thống an ninh điện tử.",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="vi" className={`${inter.variable} antialiased`}>
      <body className="font-sans">
        <Header />
        <main className="min-h-screen pt-16">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
