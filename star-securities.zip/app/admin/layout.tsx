import type React from "react"
import { AdminSidebar } from "@/components/layout/admin-sidebar"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar className="w-64 flex-shrink-0" />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  )
}
