"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Plus, MoreHorizontal } from "lucide-react"
import Link from "next/link"

const employees = [
  {
    id: 1,
    name: "Nguyễn Văn An",
    email: "an.nguyen@starsecurities.vn",
    position: "Trưởng ca bảo vệ",
    department: "Bảo vệ",
    status: "active",
    location: "Hà Nội",
    joinDate: "2020-03-15",
    phone: "0901234567",
  },
  {
    id: 2,
    name: "Trần Thị Bình",
    email: "binh.tran@starsecurities.vn",
    position: "Nhân viên bảo vệ",
    department: "Bảo vệ",
    status: "active",
    location: "TP.HCM",
    joinDate: "2021-07-20",
    phone: "0901234568",
  },
  {
    id: 3,
    name: "Lê Văn Cường",
    email: "cuong.le@starsecurities.vn",
    position: "Kỹ thuật viên",
    department: "An ninh điện tử",
    status: "leave",
    location: "Đà Nẵng",
    joinDate: "2019-11-10",
    phone: "0901234569",
  },
  {
    id: 4,
    name: "Phạm Thị Dung",
    email: "dung.pham@starsecurities.vn",
    position: "Chuyên viên HR",
    department: "Nhân sự",
    status: "active",
    location: "Hà Nội",
    joinDate: "2022-01-05",
    phone: "0901234570",
  },
  {
    id: 5,
    name: "Hoàng Văn Em",
    email: "em.hoang@starsecurities.vn",
    position: "Tài xế vận chuyển",
    department: "Vận chuyển",
    status: "active",
    location: "TP.HCM",
    joinDate: "2020-09-12",
    phone: "0901234571",
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-100 text-green-800">Đang làm việc</Badge>
    case "leave":
      return <Badge className="bg-yellow-100 text-yellow-800">Nghỉ phép</Badge>
    case "inactive":
      return <Badge className="bg-red-100 text-red-800">Không hoạt động</Badge>
    default:
      return <Badge variant="secondary">Không xác định</Badge>
  }
}

export default function EmployeesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")

  const filteredEmployees = employees.filter((employee) => {
    const matchesSearch =
      employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDepartment = departmentFilter === "all" || employee.department === departmentFilter
    return matchesSearch && matchesDepartment
  })

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Quản lý nhân viên</h1>
          <p className="text-muted-foreground mt-2">Danh sách và thông tin chi tiết nhân viên</p>
        </div>
        <Link href="/admin/hr/employees/new">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Thêm nhân viên
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Tìm kiếm nhân viên..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Chọn phòng ban" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả phòng ban</SelectItem>
                <SelectItem value="Bảo vệ">Bảo vệ</SelectItem>
                <SelectItem value="An ninh điện tử">An ninh điện tử</SelectItem>
                <SelectItem value="Nhân sự">Nhân sự</SelectItem>
                <SelectItem value="Vận chuyển">Vận chuyển</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Bộ lọc
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Employee List */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Danh sách nhân viên ({filteredEmployees.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredEmployees.map((employee) => (
              <div
                key={employee.id}
                className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback>
                      {employee.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium text-foreground">{employee.name}</h4>
                    <p className="text-sm text-muted-foreground">{employee.email}</p>
                    <p className="text-sm text-muted-foreground">
                      {employee.position} • {employee.department}
                    </p>
                    <div className="flex items-center space-x-4 mt-1">
                      <span className="text-xs text-muted-foreground">{employee.location}</span>
                      <span className="text-xs text-muted-foreground">Tham gia: {employee.joinDate}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {getStatusBadge(employee.status)}
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
