import { HRStats } from "@/components/admin/hr/hr-stats"
import { EmployeeOverview } from "@/components/admin/hr/employee-overview"
import { AttendanceChart } from "@/components/admin/hr/attendance-chart"
import { RecentHRActivities } from "@/components/admin/hr/recent-hr-activities"

export default function HRDashboard() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Quản lý nhân sự</h1>
        <p className="text-muted-foreground mt-2">Tổng quan và quản lý nhân viên Star Securities</p>
      </div>

      <HRStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <AttendanceChart />
          <EmployeeOverview />
        </div>
        <div>
          <RecentHRActivities />
        </div>
      </div>
    </div>
  )
}
