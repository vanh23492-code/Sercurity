import { DashboardStats } from "@/components/admin/dashboard-stats"
import { RecentActivities } from "@/components/admin/recent-activities"
import { QuickActions } from "@/components/admin/quick-actions"
import { SystemOverview } from "@/components/admin/system-overview"

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Bảng điều khiển quản trị</h1>
          <p className="text-muted-foreground mt-2">Tổng quan hệ thống Star Securities</p>
        </div>

        {/* Stats Grid */}
        <DashboardStats />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          {/* Left Column - 2/3 width */}
          <div className="lg:col-span-2 space-y-8">
            <SystemOverview />
            <RecentActivities />
          </div>

          {/* Right Column - 1/3 width */}
          <div className="space-y-8">
            <QuickActions />
          </div>
        </div>
      </div>
    </div>
  )
}
