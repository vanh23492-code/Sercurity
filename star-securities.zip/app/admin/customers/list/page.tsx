"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Plus, MoreHorizontal, Building } from "lucide-react"
import Link from "next/link"

const customers = [
  {
    id: 1,
    name: "Công ty TNHH ABC",
    contact: "Nguyễn Văn A",
    email: "contact@abc.com.vn",
    phone: "024 3333 1111",
    industry: "Sản xuất",
    status: "active",
    contractValue: "2.5B VNĐ",
    startDate: "2023-01-15",
    services: ["Bảo vệ", "An ninh điện tử"],
    location: "Hà Nội",
  },
  {
    id: 2,
    name: "Tập đoàn XYZ",
    contact: "Trần Thị B",
    email: "info@xyz.vn",
    phone: "028 3888 2222",
    industry: "Bất động sản",
    status: "active",
    contractValue: "5.8B VNĐ",
    startDate: "2022-08-20",
    services: ["Bảo vệ", "Vận chuyển tiền"],
    location: "TP.HCM",
  },
  {
    id: 3,
    name: "Công ty Cổ phần DEF",
    contact: "Lê Văn C",
    email: "admin@def.com",
    phone: "0236 3777 3333",
    industry: "Công nghệ",
    status: "pending",
    contractValue: "1.2B VNĐ",
    startDate: "2024-01-10",
    services: ["An ninh điện tử"],
    location: "Đà Nẵng",
  },
  {
    id: 4,
    name: "Ngân hàng GHI",
    contact: "Phạm Thị D",
    email: "security@ghi.bank",
    phone: "024 3999 4444",
    industry: "Tài chính",
    status: "active",
    contractValue: "12.5B VNĐ",
    startDate: "2021-03-05",
    services: ["Bảo vệ", "Vận chuyển tiền", "An ninh điện tử"],
    location: "Hà Nội",
  },
  {
    id: 5,
    name: "Khách sạn JKL",
    contact: "Vũ Thị E",
    email: "manager@jkl.hotel",
    phone: "0292 3666 5555",
    industry: "Du lịch",
    status: "active",
    contractValue: "800M VNĐ",
    startDate: "2023-06-12",
    services: ["Bảo vệ"],
    location: "Cần Thơ",
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-100 text-green-800">Đang hoạt động</Badge>
    case "pending":
      return <Badge className="bg-yellow-100 text-yellow-800">Chờ xử lý</Badge>
    case "expired":
      return <Badge className="bg-red-100 text-red-800">Hết hạn</Badge>
    default:
      return <Badge variant="secondary">Không xác định</Badge>
  }
}

export default function CustomerListPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [industryFilter, setIndustryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesIndustry = industryFilter === "all" || customer.industry === industryFilter
    const matchesStatus = statusFilter === "all" || customer.status === statusFilter
    return matchesSearch && matchesIndustry && matchesStatus
  })

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Danh sách khách hàng</h1>
          <p className="text-muted-foreground mt-2">Quản lý thông tin chi tiết khách hàng</p>
        </div>
        <Link href="/admin/customers/new">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Thêm khách hàng
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Tìm kiếm khách hàng..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={industryFilter} onValueChange={setIndustryFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Chọn ngành nghề" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả ngành nghề</SelectItem>
                <SelectItem value="Sản xuất">Sản xuất</SelectItem>
                <SelectItem value="Bất động sản">Bất động sản</SelectItem>
                <SelectItem value="Công nghệ">Công nghệ</SelectItem>
                <SelectItem value="Tài chính">Tài chính</SelectItem>
                <SelectItem value="Du lịch">Du lịch</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Chọn trạng thái" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="active">Đang hoạt động</SelectItem>
                <SelectItem value="pending">Chờ xử lý</SelectItem>
                <SelectItem value="expired">Hết hạn</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Bộ lọc
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Customer List */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Danh sách khách hàng ({filteredCustomers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredCustomers.map((customer) => (
              <div
                key={customer.id}
                className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback>
                      <Building className="h-6 w-6" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium text-foreground">{customer.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {customer.contact} • {customer.industry}
                    </p>
                    <p className="text-sm text-muted-foreground">{customer.email}</p>
                    <div className="flex items-center space-x-4 mt-1">
                      <span className="text-xs font-medium text-primary">{customer.contractValue}</span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">{customer.location}</span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">{customer.services.length} dịch vụ</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {getStatusBadge(customer.status)}
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
