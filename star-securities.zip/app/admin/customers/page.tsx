import { CustomerStats } from "@/components/admin/customers/customer-stats"
import { CustomerOverview } from "@/components/admin/customers/customer-overview"
import { RecentContracts } from "@/components/admin/customers/recent-contracts"
import { CustomerActivities } from "@/components/admin/customers/customer-activities"

export default function CustomersPage() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Quản lý khách hàng</h1>
        <p className="text-muted-foreground mt-2">Tổng quan và quản lý thông tin khách hàng</p>
      </div>

      <CustomerStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <CustomerOverview />
          <RecentContracts />
        </div>
        <div>
          <CustomerActivities />
        </div>
      </div>
    </div>
  )
}
