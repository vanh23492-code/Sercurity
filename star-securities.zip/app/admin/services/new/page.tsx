"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Save, Plus, X } from "lucide-react"
import Link from "next/link"

export default function NewServicePage() {
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    description: "",
    price: "",
    priceUnit: "",
    duration: "",
    features: [] as string[],
    requirements: "",
    benefits: "",
    status: "active",
  })

  const [newFeature, setNewFeature] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("New service data:", formData)
  }

  const addFeature = () => {
    if (newFeature.trim()) {
      setFormData({ ...formData, features: [...formData.features, newFeature.trim()] })
      setNewFeature("")
    }
  }

  const removeFeature = (index: number) => {
    setFormData({ ...formData, features: formData.features.filter((_, i) => i !== index) })
  }

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center space-x-4">
        <Link href="/admin/services">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Quay lại
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Thêm dịch vụ mới</h1>
          <p className="text-muted-foreground mt-2">Tạo gói dịch vụ bảo vệ mới</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Service Information */}
          <div className="lg:col-span-2">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Thông tin dịch vụ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Tên dịch vụ *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="VD: Dịch vụ bảo vệ 24/7"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Danh mục *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn danh mục" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Bảo vệ">Dịch vụ bảo vệ</SelectItem>
                        <SelectItem value="Vận chuyển">Vận chuyển tiền mặt</SelectItem>
                        <SelectItem value="An ninh điện tử">An ninh điện tử</SelectItem>
                        <SelectItem value="Tư vấn">Tư vấn an ninh</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Mô tả dịch vụ *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                    placeholder="Mô tả chi tiết về dịch vụ..."
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Giá dịch vụ *</Label>
                    <Input
                      id="price"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="15000000"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priceUnit">Đơn vị tính *</Label>
                    <Select
                      value={formData.priceUnit}
                      onValueChange={(value) => setFormData({ ...formData, priceUnit: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn đơn vị" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="VNĐ/tháng">VNĐ/tháng</SelectItem>
                        <SelectItem value="VNĐ/năm">VNĐ/năm</SelectItem>
                        <SelectItem value="VNĐ/chuyến">VNĐ/chuyến</SelectItem>
                        <SelectItem value="VNĐ/hệ thống">VNĐ/hệ thống</SelectItem>
                        <SelectItem value="VNĐ/dự án">VNĐ/dự án</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration">Thời gian thực hiện</Label>
                    <Input
                      id="duration"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                      placeholder="VD: 12 tháng"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="requirements">Yêu cầu khách hàng</Label>
                  <Textarea
                    id="requirements"
                    value={formData.requirements}
                    onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                    rows={3}
                    placeholder="Các yêu cầu cần thiết từ phía khách hàng..."
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="benefits">Lợi ích khách hàng</Label>
                  <Textarea
                    id="benefits"
                    value={formData.benefits}
                    onChange={(e) => setFormData({ ...formData, benefits: e.target.value })}
                    rows={3}
                    placeholder="Những lợi ích mà khách hàng sẽ nhận được..."
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Features & Settings */}
          <div>
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Tính năng dịch vụ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Thêm tính năng</Label>
                  <div className="flex space-x-2">
                    <Input
                      value={newFeature}
                      onChange={(e) => setNewFeature(e.target.value)}
                      placeholder="VD: Bảo vệ 24/7"
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addFeature())}
                    />
                    <Button type="button" onClick={addFeature} size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Danh sách tính năng</Label>
                  <div className="space-y-2">
                    {formData.features.map((feature, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                        <span className="text-sm">{feature}</span>
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeFeature(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border mt-6">
              <CardHeader>
                <CardTitle>Cài đặt</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Trạng thái</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Đang cung cấp</SelectItem>
                      <SelectItem value="inactive">Ngừng cung cấp</SelectItem>
                      <SelectItem value="development">Đang phát triển</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="mt-6 space-y-4">
              <Button type="submit" className="w-full">
                <Save className="h-4 w-4 mr-2" />
                Lưu dịch vụ
              </Button>
              <Link href="/admin/services">
                <Button variant="outline" className="w-full bg-transparent">
                  Hủy bỏ
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}
