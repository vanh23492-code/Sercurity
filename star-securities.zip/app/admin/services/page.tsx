import { ServiceStats } from "@/components/admin/services/service-stats"
import { ServiceOverview } from "@/components/admin/services/service-overview"
import { ServicePerformance } from "@/components/admin/services/service-performance"
import { RecentServiceActivities } from "@/components/admin/services/recent-service-activities"

export default function ServicesPage() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Quản lý dịch vụ</h1>
        <p className="text-muted-foreground mt-2">Tổng quan và quản lý các dịch vụ bảo vệ</p>
      </div>

      <ServiceStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <ServiceOverview />
          <ServicePerformance />
        </div>
        <div>
          <RecentServiceActivities />
        </div>
      </div>
    </div>
  )
}
