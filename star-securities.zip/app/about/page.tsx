import { Award, Target, Eye } from "lucide-react"

const values = [
  {
    icon: Target,
    title: "Sứ mệnh",
    description:
      "Cung cấp dịch vụ bảo vệ chuyên nghiệp, đảm bảo an toàn tuyệt đối cho khách hàng với công nghệ hiện đại và đội ngũ được đào tạo bài bản.",
  },
  {
    icon: Eye,
    title: "Tầm nhìn",
    description:
      "Trở thành công ty dịch vụ bảo vệ hàng đầu Việt Nam, được khách hàng tin tưởng và lựa chọn số 1 trong lĩnh vực an ninh.",
  },
  {
    icon: Award,
    title: "Giá trị cốt lõi",
    description:
      "Chuyên nghiệp, tin cậy, hiệu quả và luôn đặt lợi ích khách hàng lên hàng đầu trong mọi hoạt động kinh doanh.",
  },
]

const milestones = [
  { year: "2008", event: "Thành lập công ty Star Securities" },
  { year: "2012", event: "Mở rộng ra 10 tỉnh thành trên cả nước" },
  { year: "2016", event: "Đạt chứng nhận ISO 9001:2015" },
  { year: "2020", event: "Ra mắt hệ thống an ninh điện tử AI" },
  { year: "2024", event: "Phục vụ hơn 1,000 khách hàng toàn quốc" },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">Về Star Securities</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Hơn 15 năm kinh nghiệm trong lĩnh vực dịch vụ bảo vệ, chúng tôi tự hào là đối tác tin cậy của hàng nghìn
              doanh nghiệp trên toàn quốc.
            </p>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Sứ mệnh & Tầm nhìn</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <value.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">{value.title}</h3>
                <p className="text-muted-foreground text-pretty">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Hành trình phát triển</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Những cột mốc quan trọng trong quá trình xây dựng và phát triển Star Securities
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-center mb-8 last:mb-0">
                <div className="flex-shrink-0 w-20 text-right mr-8">
                  <span className="text-2xl font-bold text-primary">{milestone.year}</span>
                </div>
                <div className="flex-shrink-0 w-4 h-4 bg-primary rounded-full mr-8" />
                <div className="flex-1">
                  <p className="text-lg text-foreground">{milestone.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
